<p>
	<label>Name:</label> 
	<?php echo $name; ?>
</p>
<p>
	<label>E-mail address:</label>
	<?php echo $email; ?>
</p>
<p>
	<label>Skype:</label>
	<?php echo $skype; ?>
</p>
<p>
	<label>Department:</label>
	<?php echo $department; ?>
</p>
<p>
	<label>Phone:</label>
	<?php echo $phone; ?>
</p>
<p>
	<label>Subject:</label>
	<?php echo $subject; ?>
</p>
<p>
	<label>Message:</label>
	<?php echo $message; ?>
</p>