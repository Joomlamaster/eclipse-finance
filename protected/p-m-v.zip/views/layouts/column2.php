<?php /* @var $this Controller */ ?>
<?php $this->beginContent('//layouts/main'); ?>
<div class="content">
	<?php echo $content; ?>
</div>
<?php $this->endContent(); ?>