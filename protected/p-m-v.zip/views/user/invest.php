<?php $this->beginContent('container'); ?>

<?php $this->renderPartial('application.views.page.accountTypes'); ?>

<?php $this->endContent(); ?>