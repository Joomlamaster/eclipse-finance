<?php

/**
 * LoginForm class.
 * LoginForm is the data structure for keeping
 * user login form data. It is used by the 'login' action of 'SiteController'.
 */
class BonusForm extends CFormModel
{
	public $type_id;
	public $date;
	public $bonus_value; 
	
	/**
	 * Declares the validation rules.
	 * The rules state that username and password are required,
	 * and password needs to be authenticated.
	 */
	public function rules()
	{
		return array(
			array('type_id, date, bonus_value', 'required')
		);
	}

	/**
	 * Declares attribute labels.
	 */
	public function attributeLabels()
	{
		return array(
			'type_id' => 'Type',
			'date' => 'Date',
			'bonus_value' => 'Bonus Value'
		);
	}




}
