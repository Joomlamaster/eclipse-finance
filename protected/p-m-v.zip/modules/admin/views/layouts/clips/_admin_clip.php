<?php $this->beginClip('adminMenuClip'); ?>
<?php if($this->adminMenus): 
	foreach($this->adminMenus as $menu): 
		$this->widget('bootstrap.widgets.TbMenu', array(
		    'type' => 'list',
		    'items' => $menu
		));
	endforeach; 
else: ?>
<?php
$this->widget('bootstrap.widgets.TbMenu', array(
    'type' => 'list',
    'items' => $this->adminMenu
));
?>
<?php endif; ?>
<?php $this->endClip(); ?>