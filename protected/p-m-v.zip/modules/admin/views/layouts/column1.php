<?php $this->beginContent('/layouts/main'); ?>
<div class="span12" id="main-content">
    <?php echo $content; ?>
</div><!-- content -->
<?php $this->endContent(); ?>