<?php 
class AdminNavigation extends CWidget
{
	function init()
	{
		
	}
	
	function run()
	{ 
		if(Yii::app()->user->isAdmin())
		{
			$this->render('adminNavigation'); 
		}
	}
}
?>