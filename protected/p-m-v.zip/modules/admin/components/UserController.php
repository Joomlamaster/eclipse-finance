<?php 
class UserController extends AdminController
{
	public $user;
	
	public $subFolder = 'user';

	
	public function filters()
	{
		return array(
			'accessControl',
		);
	}
	
	public function accessRules()
	{
		return array(
			array('allow',
				'roles'=>array('manager'),
			),
			array('allow', 
				  'actions' => array('login'),
				  'users' => array('?') 
			),
			array('deny',
				'users' => array('*')
			),
		);
	}	
	
	function beforeAction($action)
	{
		if($action->id == 'login')
		{
			if(Yii::app()->user->isDude())
				$this->redirect('/admin');
		}
	
		$this->adminMenu = array(
			array('label' => 'Admin Operations'),
			array('label' => 'All users', 'icon' => 'th-list', 'url' => array($this->createUrl('user/list')), 'active' => $this->action->id == 'index' ? true : false),
			array('label' => 'ATS users', 'icon' => 'th-list', 'url' => array($this->createUrl('user/list/ats')), 'active' => $this->action->id == 'ats' ? true : false),
			array('label' => 'Withdrawal requests', 'icon' => 'th-list', 'url' => array($this->createUrl('user/list/withdrawal_requests')), 'active' => $this->action->id == 'withdrawal_requests' ? true : false),
		);
	
		Yii::app()->clientScript->registerPackage('jquery');
		Yii::app()->clientScript->registerPackage('bootstrap');
		Yii::app()->clientScript->registerCssFile(Yii::app()->request->baseUrl . '/css/jquery.fileupload-ui.css');

		if($user_id = Yii::app()->request->getQuery('user_id'))
		{
			$this->user = Users::model()->findByPk($user_id); 
		}
	
		return parent::beforeAction($action);
	}	
}

?>