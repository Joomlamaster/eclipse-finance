<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="language" content="en" />
        <title><?php echo CHtml::encode($this->pageTitle); ?></title>
        
    </head>

    <body>

        <span id="stripe">&nbsp;</span>

        <div class="container">
            <div id="mainmenu">
                <?php 
                $this->widget('bootstrap.widgets.TbNavbar', array(
                    'fixed' => false,
                    'brand' => 'Dashboard',
                    'brandUrl' => Yii::app()->createAbsoluteUrl('/admin'),
                    'brandOptions' => array(
                        'id' => 'brand'
                    ),
                    'fluid' => true,
                    'collapse' => true,
                    'items' => array(
                        array(
                            'class' => 'bootstrap.widgets.TbMenu',
                            'items' => array(
                                array('label' => 'Site',
                                      'url' => $this->createUrl('/index/index')
                        		),                        
                                array('label' => 'Pages',
									   'url' => array('/admin/pages'),
                                		'active' => Yii::app()->controller->id == 'pages'
                                ),                               
                                array('label' => 'Users',
                                      'url' => array('/admin/user/list'),
                                      'active' => Yii::app()->controller->id == 'user'
                    			),
								Yii::app()->user->checkAccess('admin') ? array('label' => 'Managers',
									'url' => array('/admin/managers'),
									'active' => Yii::app()->controller->id == 'managers'
								) : array(),  
                            	Yii::app()->user->checkAccess('admin') ? array('label' => 'Partners',
                            		'url' => array('/admin/partners'),
                            		'active' => Yii::app()->controller->id == 'partners'
                            	) : array(),                            		
                            	/*
								array('label' => 'Billing',
									'url' => array('/admin/billing'),
									'active' => Yii::app()->controller->id == 'billing'
								),       
								*/                     		                          		
                            ),
                        ),
                        '<a style="display:block; height:40px; line-height:40px; float:right;" href="/admin/user/logout">Logout</a>'
                       // '<form class="navbar-search pull-right" action=""><input type="text" class="search-query span2" placeholder="Search"></form>',
                    ))
                );
                ?>
            </div><!-- mainmenu -->
            <div id="page">
                <?php if (isset($this->breadcrumbs)): ?>
                    <?php
                    $this->widget('zii.widgets.CBreadcrumbs', array(
                    	'homeLink' => CHtml::link('Main', '/admin'),
                        'links' => $this->breadcrumbs,
                    ));
                    ?><!-- breadcrumbs -->
                <?php endif ?>

                <?php echo $content; ?>
				
				<div id="footer">
					Copyright &copy; <?php echo date('Y'); ?> by <?php echo CHtml::encode(Yii::app()->name); ?>.<br/>
					All Rights Reserved.<br/>
				</div><!-- footer -->
            </div><!-- page -->
        </div><!-- page -->
        
        <script id="modal-tmpl" type="text/x-jquery-tmpl">
        <div id="dialog" title="${title}">
  			<p class="">${desc}</p>
		</div>
		</script>
		
		
    </body>
</html>
