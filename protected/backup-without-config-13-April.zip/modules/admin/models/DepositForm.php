<?php

/**
 * LoginForm class.
 * LoginForm is the data structure for keeping
 * user login form data. It is used by the 'login' action of 'SiteController'.
 */
class DepositForm extends CFormModel
{
	//ATS, PRO or Manually
	public $type_id;
	public $date;
	public $amount; 
	public $deposit_type;
	
	/**
	 * Declares the validation rules.
	 * The rules state that username and password are required,
	 * and password needs to be authenticated.
	 */
	public function rules()
	{
		return array(
			array('type_id, date, amount', 'required')
		);
	}

	/**
	 * Declares attribute labels.
	 */
	public function attributeLabels()
	{
		return array(
			'type_id' => 'Type',
			'date' => 'Date',
			'amount' => 'Amount',
			'deposit_type' =>'Deposite Type'
		);
	}




}