<?php $this->beginContent('/layouts/main'); ?>
    <div id="sidebar-gorizontal">
        <?php
        if (isset($this->clips['adminMenuClip']))
            echo $this->clips['adminMenuClip'];
        ?>
    </div>
    <div style="clear:left"></div>
	<div id="content">
		<?php echo $content; ?>
	</div>
<?php $this->endContent(); ?>