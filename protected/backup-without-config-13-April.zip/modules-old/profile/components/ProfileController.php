<?php 
class ProfileController extends SiteController
{
	public $pages = array(); 
	public $layout = 'main'; 
	
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
		);
	}
	
	function beforeAction($action)
	{
		if(parent::beforeAction($action))
		{
			$this->pages = Pages::model()->getPagesTree();
			return true;
		}
	}	

	public function accessRules()
	{
		return array(
			array('allow',
				'users' => array('@'),
				//'expression' => 'Yii::app()->user->isAdmin'
			),
			/*
			array('deny', // deny all users
				 		'users' => array('*'),
				 ),
		*/
		);
	}	
}
?>