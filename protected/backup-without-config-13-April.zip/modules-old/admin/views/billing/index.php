<?php
/* @var $this BillingController */

$this->breadcrumbs=array(
	'Billing',
);
?>
<h1><?php echo $this->id . '/' . $this->action->id; ?></h1>

