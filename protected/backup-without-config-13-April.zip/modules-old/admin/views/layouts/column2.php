<?php $this->beginContent('/layouts/main'); ?>
	<div id="page-wrapper">
	    <div id="main-content">
	        <?php echo $content; ?>
	    </div>
    </div>
    <div id="sidebar">
        <?php
        if (isset($this->clips['adminMenuClip']))
            echo $this->clips['adminMenuClip'];
        ?>
    </div>
<?php $this->endContent(); ?>