<?php 
class AtsController extends UserController
{
	
}
?>